#pragma once
#include "afxcmn.h"  // For CListCtrl

class CListFileDialogDlg : public CDialogEx
{
public:
    CListFileDialogDlg(CWnd* pParent = nullptr);

#ifdef AFX_DESIGN_TIME
    enum { IDD = IDD_LISTFILEDIALOG_DIALOG };
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnBnClickedScanButton();
    DECLARE_MESSAGE_MAP()

private:
    HICON m_hIcon;
    CEdit m_editPath;
    CButton m_btnScan;
    CListCtrl m_listView;
    CStatic m_staticText;

    volatile bool m_bStopListing;
    HANDLE m_hThread;

    void InitListView();
    void AddFileToList(const CString& filepath);
    void ListFiles(const CString& directory);
    static UINT ListFilesThread(LPVOID pParam);
    void StartListing();
    void StopListing();
};