#include "pch.h"
#include "framework.h"
#include "ListFileDialog.h"
#include "ListFileDialogDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CListFileDialogDlg::CListFileDialogDlg(CWnd* pParent)
    : CDialogEx(IDD_LISTFILEDIALOG_DIALOG, pParent)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_bStopListing = false;
    m_hThread = NULL;
}

void CListFileDialogDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_TEXT_EDIT, m_editPath);
    DDX_Control(pDX, IDC_SCAN_BUTTON, m_btnScan);
    DDX_Control(pDX, IDC_LISTVIEW, m_listView);
    DDX_Control(pDX, IDC_STATICTXT, m_staticText);
}

BEGIN_MESSAGE_MAP(CListFileDialogDlg, CDialogEx)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_SCAN_BUTTON, &CListFileDialogDlg::OnBnClickedScanButton)
END_MESSAGE_MAP()

BOOL CListFileDialogDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    SetIcon(m_hIcon, TRUE);
    SetIcon(m_hIcon, FALSE);

    InitListView();
    return TRUE;
}

void CListFileDialogDlg::InitListView()
{
    m_listView.InsertColumn(0, _T("File path"), LVCFMT_LEFT, 400);
}

void CListFileDialogDlg::AddFileToList(const CString& filepath)
{
    int nIndex = m_listView.GetItemCount();
    m_listView.InsertItem(nIndex, filepath);
}

void CListFileDialogDlg::ListFiles(const CString& directory)
{
    CString searchPath = directory + _T("\\*.*");
    WIN32_FIND_DATA findData;
    HANDLE hFind = FindFirstFile(searchPath, &findData);

    if (hFind == INVALID_HANDLE_VALUE) return;

    do {
        if (m_bStopListing) break;

        if (_tcscmp(findData.cFileName, _T(".")) == 0 ||
            _tcscmp(findData.cFileName, _T("..")) == 0)
            continue;

        CString fullPath = directory + _T("\\") + findData.cFileName;
        AddFileToList(fullPath);

        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            ListFiles(fullPath);
        }
    } while (FindNextFile(hFind, &findData) && !m_bStopListing);

    FindClose(hFind);
}

UINT CListFileDialogDlg::ListFilesThread(LPVOID pParam)
{
    CListFileDialogDlg* pDlg = (CListFileDialogDlg*)pParam;
    CString* directory = new CString;
    pDlg->m_editPath.GetWindowText(*directory);
    pDlg->ListFiles(*directory);
    delete directory;

    // Re-enable controls when done
    pDlg->PostMessage(WM_COMMAND, MAKEWPARAM(IDC_SCAN_BUTTON, BN_CLICKED), 0);
    return 0;
}

void CListFileDialogDlg::StartListing()
{
    m_bStopListing = false;
    m_editPath.EnableWindow(FALSE);
    m_btnScan.SetWindowText(_T("Stop"));
    m_listView.DeleteAllItems();

    AfxBeginThread(ListFilesThread, this);
}

void CListFileDialogDlg::StopListing()
{
    m_bStopListing = true;
    if (m_hThread) {
        WaitForSingleObject(m_hThread, INFINITE);
        CloseHandle(m_hThread);
        m_hThread = NULL;
    }
    m_editPath.EnableWindow(TRUE);
    m_btnScan.SetWindowText(_T("Start"));
}

void CListFileDialogDlg::OnBnClickedScanButton()
{
    CString buttonText;
    m_btnScan.GetWindowText(buttonText);

    if (buttonText == _T("Scan")) {
        StartListing();
    }
    else {
        StopListing();
    }
}

void CListFileDialogDlg::OnPaint()
{
    if (IsIconic()) {
        CPaintDC dc(this);
        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        dc.DrawIcon(x, y, m_hIcon);
    }
    else {
        CDialogEx::OnPaint();
    }
}

HCURSOR CListFileDialogDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}